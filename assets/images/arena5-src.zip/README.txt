If you want to run this code locally, run the game from within a local webserver for the sound loading to work correctly.
e.g. localhost:8080/arena5/index.html

All game graphics, sounds and code Copyright (c) 2014 Kevin Roast kevtoast@yahoo.com
See license.txt